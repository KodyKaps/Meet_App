import {getAccessToken} from './handler.js'
export const handler = (event, context, callback) => {
    return getAccessToken()
}